<?php get_header(); ?>
<div id="left" class="eleven columns" >
<div class="post">
<div class="title">
<h2>Not Found !</h2>
</div>
<div class="entry"><p>We're very sorry, but the page you requested has not been found! It may have been moved or deleted..</p></div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>